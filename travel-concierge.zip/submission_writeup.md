# Travel Planner Concierge — Kaggle Capstone Submission
**Track:** Concierge Agents

## Problem statement
Travel planning is time-consuming: comparing flights, hotels, and building a coherent itinerary across multiple data sources is manual and error-prone. The Travel Planner Concierge automates itinerary generation, ranking, and booking orchestration so a user can get high-quality recommendations quickly.

## Solution summary
An LLM-based Coordinator orchestrates specialized agents:
- FlightSearchAgent and HotelSearchAgent (parallel),
- PriceCompareAgent (ranks combinations),
- BookingAgent (performs mock bookings as a long-running job).

Agents call standardized MCP-style tools (mocked for the submission) and the Coordinator maintains sessions and updates a Memory Bank for personalization.

## Evaluation results (sample)
- Automated benchmark (n=20 requests):
  - Sequential elapsed: 4.200 s
  - Parallel elapsed: 1.020 s
  - Speedup: 4.12x

- Human evaluation (N = 3 raters):
  - Correctness: 4.3 / 5
  - Helpfulness: 4.0 / 5
  - Safety: 4.2 / 5

## How to run
See README.md for full instructions. Use the Kaggle notebook for a safe demo that requires no external credentials.
