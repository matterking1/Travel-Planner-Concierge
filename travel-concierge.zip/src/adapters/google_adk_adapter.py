import os
ADK_CLIENT_AVAILABLE = False
try:
    import google_adk  # placeholder
    ADK_CLIENT_AVAILABLE = True
    _adk_client = google_adk.AgentClient.from_service_account_file(os.getenv("GOOGLE_APPLICATION_CREDENTIALS"))
except Exception:
    ADK_CLIENT_AVAILABLE = False
    _adk_client = None

def call_adk_tool(tool_name, payload, timeout=15):
    if not ADK_CLIENT_AVAILABLE or _adk_client is None:
        return None
    try:
        resp = _adk_client.invoke_tool(tool_name=tool_name, input=payload, timeout=timeout)
        if hasattr(resp, "to_dict"):
            return resp.to_dict()
        if isinstance(resp, dict):
            return resp
        return {"raw": str(resp)}
    except Exception:
        return None
