# evaluation_runner.py
import asyncio
import csv
import time
from pathlib import Path
from src.agents.flight_agent import FlightSearchAgent

OUTPUT_DIR = Path("metrics")
OUTPUT_DIR.mkdir(exist_ok=True)

def sample_request(i=0):
    return {
        "flight": {"origin": "NYC", "dest": "PAR", "depart_date": "2026-05-10", "return_date": "2026-05-15", "passengers": 1},
        "hotel": {"city": "Paris", "checkin": "2026-05-10", "checkout": "2026-05-15", "guests": 1, "nights": 5}
    }

async def plan_sequential(n=5):
    agent = FlightSearchAgent()
    start = time.time()
    for i in range(n):
        req = sample_request(i)
        await agent.search(req["flight"])
    elapsed = time.time() - start
    await agent.close()
    return elapsed

async def plan_parallel(n=5):
    agent = FlightSearchAgent()
    start = time.time()
    tasks = []
    for i in range(n):
        req = sample_request(i)
        tasks.append(asyncio.create_task(agent.search(req["flight"])))
    results = await asyncio.gather(*tasks)
    elapsed = time.time() - start
    await agent.close()
    return elapsed

def write_csv(rows, path: str):
    with open(path, "w", newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['mode','requests','elapsed_s','avg_s','speedup'])
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

async def run_bench(n_requests=10):
    seq_elapsed = await plan_sequential(n_requests)
    par_elapsed = await plan_parallel(n_requests)
    avg_seq = seq_elapsed / n_requests
    avg_par = par_elapsed / n_requests
    speedup = seq_elapsed / par_elapsed if par_elapsed>0 else None
    rows = [
        {'mode':'sequential','requests':n_requests,'elapsed_s':round(seq_elapsed,3),'avg_s':round(avg_seq,3),'speedup':''},
        {'mode':'parallel','requests':n_requests,'elapsed_s':round(par_elapsed,3),'avg_s':round(avg_par,3),'speedup':round(speedup,3) if speedup else ''}
    ]
    out = OUTPUT_DIR / 'results.csv'
    write_csv(rows, str(out))
    print('Wrote metrics to', out)
    return rows

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--requests', type=int, default=10)
    args = parser.parse_args()
    asyncio.run(run_bench(args.requests))
