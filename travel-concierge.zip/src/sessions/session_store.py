import uuid, json, os
class SessionStore:
    def __init__(self, path='data/sessions.json'):
        self.path = path
        try:
            with open(self.path) as f:
                self.db = json.load(f)
        except:
            self.db = {}
    def create_session(self, user_id, request):
        sid = str(uuid.uuid4())
        self.db[sid] = {"user_id":user_id,"request":request,"state":{}}
        self._save()
        return sid
    def update_session(self, sid, data):
        self.db.setdefault(sid,{}).update(data)
        self._save()
    def get_session(self, sid):
        return self.db.get(sid, {})
    def _save(self):
        os.makedirs(os.path.dirname(self.path) or '.', exist_ok=True)
        with open(self.path,'w') as f:
            json.dump(self.db, f, default=str)
