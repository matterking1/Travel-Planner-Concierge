# Video script — Travel Planner Concierge (2 minutes)

Duration: ~2:30

0:00 — 0:10 — Opening
- On-screen: Project title card — "Travel Planner Concierge — Kaggle Capstone"
- Voiceover: "Hi — this is a 2-minute demo of the Travel Planner Concierge, a multi-agent travel assistant."

0:10 — 0:35 — Problem & Solution
- On-screen: problem bullet points
- Voiceover: "It automates itinerary creation by orchestrating specialized agents that search flights, hotels, compare prices, and perform bookings."

0:35 — 0:55 — Architecture overview
- On-screen: simplified architecture diagram
- Voiceover: "A Coordinator LLM plans tasks and runs FlightSearch and HotelSearch in parallel via MCP-style tools. Sessions and a Memory Bank personalize recommendations."

0:55 — 1:35 — Live demo (recorded from notebook)
- On-screen: Kaggle Notebook running the `plan_trip` demo
- Voiceover: "Here I'm asking it to plan a 5-day trip to Paris..."

1:35 — 2:00 — Booking & long-running jobs
- On-screen: Start booking — show booking job state transitions
- Voiceover: "BookingAgent runs as a background job with pause/resume support."

2:00 — 2:30 — Observability & evaluation
- On-screen: sample logs/traces & `metrics/results.csv`
- Voiceover: "The project includes structured logs and a benchmark script that measures parallel vs sequential speedups."

