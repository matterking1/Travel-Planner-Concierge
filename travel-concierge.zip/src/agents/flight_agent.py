import asyncio, os, random, httpx
from src.adapters.google_adk_adapter import call_adk_tool, ADK_CLIENT_AVAILABLE

MAX_RETRIES = int(os.getenv("FLIGHT_MAX_RETRIES", "3"))
INITIAL_BACKOFF = float(os.getenv("FLIGHT_BACKOFF", "0.5"))
SKYPICKER_BASE = os.getenv("SKYPICKER_BASE", "")

class FlightSearchAgent:
    def __init__(self, timeout=10):
        self.timeout = timeout
        self.client = httpx.AsyncClient(timeout=self.timeout)

    async def search(self, query):
        # try ADK
        if ADK_CLIENT_AVAILABLE:
            r = call_adk_tool("flight_search", query, timeout=self.timeout)
            if r:
                return self._normalize_adk_response(r)
        # try skypicker
        if SKYPICKER_BASE:
            params = {"fly_from": query.get("origin"), "fly_to": query.get("dest"), "date_from": query.get("depart_date"), "date_to": query.get("depart_date"), "adults": query.get("passengers",1)}
            for attempt in range(1, MAX_RETRIES+1):
                try:
                    resp = await self.client.get(f"{SKYPICKER_BASE}/flights", params=params)
                    resp.raise_for_status()
                    return self._normalize_skypicker_response(resp.json())
                except Exception:
                    await asyncio.sleep(INITIAL_BACKOFF*(2**(attempt-1)))
        # fallback mock
        return {"options":[{"id":"FL-MOCK-1","airline":"MockAir","price":480,"stops":0,"depart":query.get("depart_date")},{"id":"FL-MOCK-2","airline":"BudgetFly","price":350,"stops":1,"depart":query.get("depart_date")}]}

    def _normalize_adk_response(self, resp):
        options = []
        raw = resp.get("options") or resp.get("data") or []
        for o in raw:
            options.append({"id": o.get("id","x"), "airline": o.get("airline","Unknown"), "price": o.get("price",0), "stops": o.get("stops",0), "depart": o.get("depart","")})
        return {"options": options}

    def _normalize_skypicker_response(self, resp):
        options = []
        for item in resp.get("data",[]):
            options.append({"id": item.get("id"), "airline": item.get("airlines",['Unknown'])[0] if item.get("airlines") else 'Unknown', "price": item.get("price",0), "stops": len(item.get("route",[]))-1, "depart": item.get("dTimeUTC","")})
        return {"options": options}

    async def close(self):
        await self.client.aclose()
