from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn

app = FastAPI()

class FlightQuery(BaseModel):
    origin: str
    dest: str
    depart_date: str
    return_date: str
    passengers: int

class HotelQuery(BaseModel):
    city: str
    checkin: str
    checkout: str
    guests: int

@app.post("/flight_search")
def flight_search(q: FlightQuery):
    return {"options":[{"id":"FL1","airline":"MockAir","price":480,"stops":0,"depart":q.depart_date},{"id":"FL2","airline":"BudgetFly","price":350,"stops":1,"depart":q.depart_date}]}

@app.post("/hotel_search")
def hotel_search(q: HotelQuery):
    return {"options":[{"id":"HT1","name":"Hotel Example","price_per_night":120,"rating":4.3},{"id":"HT2","name":"Budget Inn","price_per_night":75,"rating":3.6}]}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8001)
