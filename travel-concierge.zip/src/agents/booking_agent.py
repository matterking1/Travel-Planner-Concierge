import time
from src.sessions.session_store import SessionStore
from src.observability.telemetry import log_event

class BookingAgent:
    def __init__(self):
        self.store = SessionStore()
    def book_itinerary(self, session_id, itinerary):
        self.store.update_session(session_id, {"job_status":"in_progress"})
        log_event("booking_started", {"session":session_id})
        steps = ["reserve_flight","reserve_hotel","confirm_payment"]
        for step in steps:
            time.sleep(1)
            log_event("booking_step", {"session":session_id,"step":step})
        self.store.update_session(session_id, {"job_status":"completed"})
        log_event("booking_completed", {"session":session_id})
        return {"status":"completed"}
