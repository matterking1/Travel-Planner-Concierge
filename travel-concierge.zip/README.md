# Travel Planner Concierge — Capstone Project

**Track:** Concierge Agents  
**Project:** Travel Planner Concierge — LLM-coordinated multi-agent travel planner (flight + hotel search, itinerary ranking, mock booking)

This repository contains a production-oriented implementation of the Travel Planner Concierge capstone. It demonstrates multi-agent orchestration, tools (MCP + ADK adapter + mock MCP), sessions & memory, long-running job support, observability (logs/traces/metrics), and an evaluation harness.

## Quick start (local, Docker Compose)
Requirements: Docker & docker-compose.

1. Build & run:
```bash
docker-compose up --build
```

2. The mock MCP server will be available at http://localhost:8001.

3. To run the evaluation benchmark inside the coordinator container or locally:
```bash
python evaluation_runner.py --requests 10
```

## Quick start (Kaggle notebook)
Open `notebook.ipynb` and run the cells in order. The notebook runs in demo/fallback mode (no external credentials required).

## Contents
- `src/` - application source
- `notebook.ipynb` - Kaggle-ready demo notebook
- `docker-compose.yml` - demo stack (mock MCP, Redis, coordinator, worker)
- `prometheus.yml` - Prometheus config
- `evaluation_runner.py` - benchmark script
- `submission_writeup.md` - final writeup for Kaggle submission
- `video_script.md` - demo video script

## Notes
- ADK integration is optional. The repo contains an adapter that will call Google ADK when credentials and SDK are present, otherwise falls back to mocks or public API (Skypicker).
- Do NOT commit Google credentials; use environment variables or a secrets manager.

