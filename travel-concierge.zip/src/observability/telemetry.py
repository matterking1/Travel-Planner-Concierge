import json, time
def log_event(name, payload):
    payload = dict(payload)
    payload['_ts'] = time.time()
    print(json.dumps({'event':name,'payload':payload}))
