import json, os
class MemoryBank:
    def __init__(self, path='data/memory.json'):
        self.path = path
        try:
            with open(self.path) as f:
                self.db = json.load(f)
        except:
            self.db = {}
    def get_user(self, user_id):
        return self.db.get(user_id, {})
    def upsert_user(self, user_id, profile):
        self.db[user_id] = profile
        os.makedirs(os.path.dirname(self.path) or '.', exist_ok=True)
        with open(self.path,'w') as f:
            json.dump(self.db, f)
