import asyncio, os
from src.sessions.session_store import SessionStore
from src.memory.memory_bank import MemoryBank
from src.observability.telemetry import log_event
from src.agents.flight_agent import FlightSearchAgent
import httpx

MCP_BASE = os.getenv("MCP_BASE","http://localhost:8001")
session_store = SessionStore()
memory = MemoryBank()

async def call_mcp(endpoint, payload):
    url = f"{MCP_BASE}/{endpoint}"
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(url, json=payload)
        r.raise_for_status()
        return r.json()

async def plan_trip(user_id, request):
    sid = session_store.create_session(user_id, request)
    flight_task = asyncio.create_task(call_mcp("flight_search", request["flight"]))
    hotel_task = asyncio.create_task(call_mcp("hotel_search", request["hotel"]))
    flights, hotels = await asyncio.gather(flight_task, hotel_task)
    itineraries = []
    nights = request["hotel"].get("nights",5)
    for f in flights["options"]:
        for h in hotels["options"]:
            total = f.get("price",0) + h.get("price_per_night",0)*nights
            itineraries.append({"flight":f,"hotel":h,"price":total})
    itineraries = sorted(itineraries, key=lambda x: x["price"])
    session_store.update_session(sid, {"itineraries":itineraries})
    log_event("plan_trip", {"session":sid, "count": len(itineraries)})
    return {"session_id": sid, "itineraries": itineraries}
